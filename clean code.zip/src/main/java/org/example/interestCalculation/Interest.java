package org.example.interestCalculation;

public interface Interest {
    public Double calculateInterest(Double principalAmount, Double rateOfInterest, Double time);
}
